# Manish Kumar — Portfolio Website

A responsive personal portfolio built with plain HTML, CSS, and JavaScript. It uses a purple-and-black theme and includes a light/dark mode toggle.

## Files

- `index.html` — page content and portfolio sections
- `style.css` — layout, responsive styling, and theme colors
- `script.js` — mobile menu and light/dark mode
- `README.md` — these instructions

## Run it on Windows 11

1. Extract the ZIP file.
2. Open the extracted `manish_portfolio` folder in Visual Studio Code.
3. Open `index.html`.
4. If you have the VS Code **Live Server** extension, right-click `index.html` and choose **Open with Live Server**. Otherwise, double-click `index.html` to open it in your browser.

## Publish free with GitHub Pages

1. Sign in to GitHub and create a new public repository, for example `manish-portfolio`.
2. Upload `index.html`, `style.css`, `script.js`, and `README.md` to the repository's root folder.
3. Open the repository's **Settings → Pages**.
4. Under **Build and deployment**, select **Deploy from a branch**.
5. Choose the `main` branch and `/ (root)` folder, then click **Save**.
6. Wait a few minutes. GitHub Pages will show your published website URL in the Pages settings.

## Personal details to double-check

- The email currently shown is `manishkumar6209182914@gmail.com`, based on the most recent portfolio details shared.
- The LinkedIn link points to `https://www.linkedin.com/in/manish-kumar-9a1a01442/`. Confirm it opens your profile.
- Project cards are starter examples/placeholders. Replace them with your actual projects as you build them.
- No profile photograph was included, so the hero uses a stylized “MK” code card instead.

Edit the relevant text and links in `index.html` whenever you need to update your portfolio.
